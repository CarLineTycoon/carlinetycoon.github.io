return {
  day_started = function(ctx, event)
    for _, result in ipairs(ctx.results()) do
      if result.requestId == ctx.store.requestId then
        ctx.store.accepted = result.accepted
        ctx.store.reason = result.reason
      end
    end
    if ctx.store.requested then return end
    local page = ctx.models(nil, 1)
    if #page.items == 0 then return end
    local request = ctx.actions.set_model_price(page.items[1].id, 10000)
    ctx.store.requested = true
    ctx.store.requestId = request
  end,
  sales_summary = function(ctx, event)
    ctx.store.sales = (ctx.store.sales or 0) + event.count
    clt.log(tostring(ctx.store.sales))
  end
}
