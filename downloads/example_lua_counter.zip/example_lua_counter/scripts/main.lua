return {
  sales_summary = function(ctx, event)
    ctx.store.sales = (ctx.store.sales or 0) + event.count
    local messages = {"Sale recorded", "Counter updated", "Sales counted"}
    clt.log(messages[ctx.random.int(1, 3)])
  end
}
